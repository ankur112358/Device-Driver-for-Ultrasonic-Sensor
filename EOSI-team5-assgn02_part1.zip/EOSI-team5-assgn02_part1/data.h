////structure of the data used to store in buffer


struct data {
	unsigned long long timestamp;
	int distance;
};
